/*global QUnit*/

sap.ui.define([
	"projectqm/controller/QM.controller"
], function (Controller) {
	"use strict";

	QUnit.module("QM Controller");

	QUnit.test("I should test the QM controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
