sap.ui.define([
	"projectqm/test/unit/controller/QM.controller"
], function () {
	"use strict";
});
