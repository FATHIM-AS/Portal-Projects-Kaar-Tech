/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["projectqm/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
