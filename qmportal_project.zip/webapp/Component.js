sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/model/odata/v2/ODataModel"
], function (UIComponent, ODataModel) {
    "use strict";

    return UIComponent.extend("com.kaar.qmportal.Component", {

        metadata: {
            manifest: "json"
        },

        init: function () {

            UIComponent.prototype.init.apply(this, arguments);

            var oModel = new ODataModel("/sap/opu/odata/SAP/ZQM_PORTAL20_SRV_01/", {
                json: true,
                useBatch: false
            });

            this.setModel(oModel);

            this.getRouter().initialize();
        }
    });
});