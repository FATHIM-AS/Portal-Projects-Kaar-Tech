sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox"
], function (
    Controller,
    MessageBox
) {
    "use strict";

    return Controller.extend(
        "com.kaar.qmportal.controller.Dashboard",
        {

            onInit: function () {

                this.getOwnerComponent()
                    .getRouter()
                    .getRoute("dashboard")
                    .attachPatternMatched(
                        this._onRouteMatched,
                        this
                    );
            },

            _onRouteMatched: function () {

                var oUser =
                    this._getSessionUser();

                if (!oUser) {

                    this.getOwnerComponent()
                        .getRouter()
                        .navTo("login");

                    return;
                }

                this.byId("txtUser")
                    .setText(
                        oUser.Employeeid +
                        " | " +
                        oUser.Plant
                    );

                this.byId("welcomeTitle")
                    .setText(
                        "Welcome " +
                        oUser.Role
                    );

                this.byId("welcomeSub")
                    .setText(
                        "SAP Quality Management Portal"
                    );
            },

            onNavInspectionLot: function () {

                this.getOwnerComponent()
                    .getRouter()
                    .navTo("inspectionLot");
            },

            onNavResultRecords: function () {

                this.getOwnerComponent()
                    .getRouter()
                    .navTo("resultRecords");
            },

            onNavUsageDecision: function () {

                this.getOwnerComponent()
                    .getRouter()
                    .navTo("usageDecision");
            },

            onLogout: function () {

                MessageBox.confirm(
                    "Are you sure you want to logout?",
                    {

                        actions: [
                            MessageBox.Action.YES,
                            MessageBox.Action.NO
                        ],

                        onClose: function (sAction) {

                            if (
                                sAction ===
                                MessageBox.Action.YES
                            ) {

                                sessionStorage.removeItem(
                                    "qm_user"
                                );

                                this.getOwnerComponent()
                                    .getRouter()
                                    .navTo("login");
                            }

                        }.bind(this)

                    }
                );
            },

            _getSessionUser: function () {

                var sUser =
                    sessionStorage.getItem(
                        "qm_user"
                    );

                try {

                    return sUser
                        ? JSON.parse(sUser)
                        : null;

                } catch (e) {

                    return null;
                }
            }

        }
    );

});