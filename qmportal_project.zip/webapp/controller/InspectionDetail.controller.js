sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    "sap/ui/model/json/JSONModel"
], function (
    Controller,
    MessageBox,
    JSONModel
) {
    "use strict";

    return Controller.extend(
        "com.kaar.qmportal.controller.InspectionDetail",
        {

            onInit: function () {

                var oRouter =
                    this.getOwnerComponent().getRouter();

                oRouter
                    .getRoute("inspectionDetail")
                    .attachPatternMatched(
                        this._onRouteMatched,
                        this
                    );

            },

            _onRouteMatched: function (oEvent) {

                var sLotId =
                    oEvent.getParameter("arguments").lotId;

                this._loadInspectionDetail(sLotId);

            },

            _loadInspectionDetail: function (sLotId) {

                var oModel =
                    this.getOwnerComponent().getModel();

                var aFilters = [
                    new sap.ui.model.Filter(
                        "Inspectionlot",
                        sap.ui.model.FilterOperator.EQ,
                        sLotId
                    )
                ];

                oModel.read("/InspectionLotSet", {

                    filters: aFilters,

                    success: function (oData) {

                        if (
                            !oData.results ||
                            oData.results.length === 0
                        ) {

                            MessageBox.error(
                                "No inspection detail found."
                            );

                            return;
                        }

                        var oDetail =
                            oData.results[0];

                        if (oDetail.Udstatus === "X") {

                            oDetail.StatusText =
                                "Completed";

                            oDetail.StatusState =
                                "Success";

                        } else {

                            oDetail.StatusText =
                                "Pending";

                            oDetail.StatusState =
                                "Warning";

                        }

                        if (oDetail.Createddate) {

                            var aMatch =
                                /\d+/.exec(
                                    oDetail.Createddate
                                );

                            if (aMatch) {

                                var oDate =
                                    new Date(
                                        parseInt(
                                            aMatch[0],
                                            10
                                        )
                                    );

                                oDetail.CreatedDateText =
                                    oDate.toLocaleDateString(
                                        "en-GB"
                                    );

                            }

                        }

                        var oJsonModel =
                            new JSONModel(oDetail);

                        this.getView().setModel(
                            oJsonModel,
                            "detail"
                        );

                    }.bind(this),

                    error: function (oError) {

                        console.log(oError);

                        MessageBox.error(
                            "Failed to load inspection detail."
                        );

                    }

                });

            },

            onNavBack: function () {

                this.getOwnerComponent()
                    .getRouter()
                    .navTo("inspectionLot");

            },

            onLogout: function () {

                sessionStorage.clear();

                this.getOwnerComponent()
                    .getRouter()
                    .navTo("login");

            }

        }
    );

});