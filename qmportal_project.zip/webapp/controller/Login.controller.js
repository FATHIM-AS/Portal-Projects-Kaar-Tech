sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast"
], function (
    Controller,
    MessageToast
) {
    "use strict";

    return Controller.extend(
        "com.kaar.qmportal.controller.Login",
        {

            onInit: function () {

            },

            onLogin: function () {

                var sEmployeeId =
                    this.byId("inputEmployeeId")
                        .getValue()
                        .trim();

                var sPassword =
                    this.byId("inputPassword")
                        .getValue()
                        .trim();

                var oError =
                    this.byId("loginError");

                oError.setVisible(false);

                if (!sEmployeeId || !sPassword) {

                    oError.setText(
                        "Please enter Employee ID and Password."
                    );

                    oError.setVisible(true);

                    return;
                }

                this.byId("loginBusy")
                    .setVisible(true);

                var oModel =
                    this.getOwnerComponent()
                        .getModel();

                var oPayload = {

                    Employeeid: sEmployeeId,
                    Password: sPassword

                };

                oModel.create(
                    "/LoginSet",
                    oPayload,
                    {

                        success: function (oData) {

                            this.byId("loginBusy")
                                .setVisible(false);

                            if (
                                oData &&
                                oData.Employeeid
                            ) {

                                sessionStorage.setItem(
                                    "qm_user",
                                    JSON.stringify(oData)
                                );

                                MessageToast.show(
                                    "Login Successful"
                                );

                                this.getOwnerComponent()
                                    .getRouter()
                                    .navTo("dashboard");

                            } else {

                                oError.setText(
                                    "Invalid Employee ID or Password."
                                );

                                oError.setVisible(true);
                            }

                        }.bind(this),

                        error: function () {

                            this.byId("loginBusy")
                                .setVisible(false);

                            oError.setText(
                                "Invalid Employee ID or Password."
                            );

                            oError.setVisible(true);

                        }.bind(this)

                    }
                );

            }

        }
    );

});