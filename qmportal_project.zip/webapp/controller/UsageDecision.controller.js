sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast"
], function (
    Controller,
    JSONModel,
    Filter,
    FilterOperator,
    MessageToast
) {
    "use strict";

    return Controller.extend(
        "com.kaar.qmportal.controller.UsageDecision",
        {

            onInit: function () {

                this._loadData();

            },

            _loadData: function () {

                var oModel =
                    this.getOwnerComponent().getModel();

                oModel.read("/UsageSet", {

                    success: function (oData) {

                        var oJsonModel =
                            new JSONModel(oData);

                        this.getView().setModel(
                            oJsonModel,
                            "usage"
                        );

                        this.byId("usageCount")
                            .setText(
                                oData.results.length +
                                " Records Found"
                            );

                    }.bind(this),

                    error: function (oError) {

                        console.log(oError);

                        MessageToast.show(
                            "Failed to load usage data"
                        );

                    }

                });

            },

            onSearch: function () {

                this._applyFilters();

            },

            onFilterChange: function () {

                this._applyFilters();

            },

            _applyFilters: function () {

                var aFilters = [];

                var sSearch =
                    this.byId("usageSearchField")
                        .getValue();

                var sPlant =
                    this.byId("plantFilter")
                        .getSelectedKey();

                var sStatus =
                    this.byId("statusFilter")
                        .getSelectedKey();

                var sDecision =
                    this.byId("decisionFilter")
                        .getSelectedKey();

                var sInspectionType =
                    this.byId("inspectionTypeFilter")
                        .getSelectedKey();

                if (sSearch) {

                    aFilters.push(

                        new Filter({

                            filters: [

                                new Filter(
                                    "Inspectionlot",
                                    FilterOperator.Contains,
                                    sSearch
                                ),

                                new Filter(
                                    "Material",
                                    FilterOperator.Contains,
                                    sSearch
                                ),

                                new Filter(
                                    "Plant",
                                    FilterOperator.Contains,
                                    sSearch
                                ),

                                new Filter(
                                    "Materialdescription",
                                    FilterOperator.Contains,
                                    sSearch
                                )

                            ],

                            and: false

                        })

                    );

                }

                if (sPlant) {

                    aFilters.push(

                        new Filter(
                            "Plant",
                            FilterOperator.EQ,
                            sPlant
                        )

                    );

                }

                if (sStatus) {

                    aFilters.push(

                        new Filter(
                            "Inspectionstatus",
                            FilterOperator.EQ,
                            sStatus
                        )

                    );

                }

                if (sDecision) {

                    aFilters.push(

                        new Filter(
                            "Usagedecisiontext",
                            FilterOperator.EQ,
                            sDecision
                        )

                    );

                }

                if (sInspectionType) {

                    aFilters.push(

                        new Filter(
                            "Inspectiontype",
                            FilterOperator.EQ,
                            sInspectionType
                        )

                    );

                }

                this.byId("usageTable")
                    .getBinding("rows")
                    .filter(aFilters);

            },

            onRefresh: function () {

                this.byId("usageSearchField")
                    .setValue("");

                this.byId("plantFilter")
                    .setSelectedKey("");

                this.byId("statusFilter")
                    .setSelectedKey("");

                this.byId("decisionFilter")
                    .setSelectedKey("");

                this.byId("inspectionTypeFilter")
                    .setSelectedKey("");

                this._loadData();

            },

            onNavBack: function () {

                this.getOwnerComponent()
                    .getRouter()
                    .navTo("dashboard");

            },

            onLogout: function () {

                sessionStorage.clear();

                this.getOwnerComponent()
                    .getRouter()
                    .navTo("login");

            }

        }
    );

});