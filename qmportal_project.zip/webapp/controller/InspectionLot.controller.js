sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast"
], function (
    Controller,
    JSONModel,
    Filter,
    FilterOperator,
    MessageToast
) {
    "use strict";

    return Controller.extend("com.kaar.qmportal.controller.InspectionLot", {

        onInit: function () {
            this._loadInspectionLots();
        },

        _loadInspectionLots: function () {

            var oModel = this.getOwnerComponent().getModel();

            oModel.read("/InspectionLotSet", {

                success: function (oData) {

                    var aResults = oData.results || [];

                    aResults.forEach(function (oItem) {

                        if (oItem.Udstatus === "X") {
                            oItem.StatusText = "Completed";
                            oItem.StatusState = "Success";
                        } else {
                            oItem.StatusText = "Pending";
                            oItem.StatusState = "Warning";
                        }

                        if (oItem.Createddate) {

                            var aMatch = /\d+/.exec(oItem.Createddate);

                            if (aMatch) {

                                var oDate = new Date(parseInt(aMatch[0], 10));

                                oItem.CreatedDateText =
                                    oDate.toLocaleDateString("en-GB");

                            }

                        } else {

                            oItem.CreatedDateText = "";

                        }

                    });

                    var oJsonModel = new JSONModel({
                        results: aResults
                    });

                    this.getView().setModel(oJsonModel, "inspection");

                    this.byId("recordCount")
                        .setText(aResults.length + " Records Found");

                    this._setPlantFilters(aResults);

                }.bind(this),

                error: function () {

                    MessageToast.show("Unable to load inspection lots");

                }

            });

        },

        _setPlantFilters: function (aResults) {

            var aPlants = [];
            var oUnique = {};

            aPlants.push({
                key: "",
                text: "All Plants"
            });

            aResults.forEach(function (oItem) {

                if (oItem.Plant && !oUnique[oItem.Plant]) {

                    oUnique[oItem.Plant] = true;

                    aPlants.push({
                        key: oItem.Plant,
                        text: oItem.Plant
                    });

                }

            });

            var oFilterModel = new JSONModel({

                Plants: aPlants,

                Status: [
                    {
                        key: "",
                        text: "All Status"
                    },
                    {
                        key: "Completed",
                        text: "Completed"
                    },
                    {
                        key: "Pending",
                        text: "Pending"
                    }
                ]

            });

            this.getView().setModel(oFilterModel, "filters");

        },

        onSearch: function () {
            this._applyFilters();
        },

        onFilterChange: function () {
            this._applyFilters();
        },

        _applyFilters: function () {

            var aFilters = [];

            var sSearch = this.byId("inspectionSearchField").getValue();

            var sPlant =
                this.byId("inspectionPlantFilter").getSelectedKey();

            var sStatus =
                this.byId("inspectionStatusFilter").getSelectedKey();

            if (sSearch) {

                aFilters.push(

                    new Filter({

                        filters: [

                            new Filter(
                                "Inspectionlot",
                                FilterOperator.Contains,
                                sSearch
                            ),

                            new Filter(
                                "Material",
                                FilterOperator.Contains,
                                sSearch
                            )

                        ],

                        and: false

                    })

                );

            }

            if (sPlant) {

                aFilters.push(

                    new Filter(
                        "Plant",
                        FilterOperator.EQ,
                        sPlant
                    )

                );

            }

            if (sStatus) {

                aFilters.push(

                    new Filter(
                        "StatusText",
                        FilterOperator.EQ,
                        sStatus
                    )

                );

            }

            var oBinding =
                this.byId("inspectionTable").getBinding("rows");

            oBinding.filter(aFilters);

        },

        onRefresh: function () {
            this._loadInspectionLots();
        },

        onLotPress: function (oEvent) {

            var sLot =
                oEvent.getSource().getText();

            this.getOwnerComponent()
                .getRouter()
                .navTo("inspectionDetail", {
                    lotId: sLot
                });

        },

        onNavBack: function () {

            this.getOwnerComponent()
                .getRouter()
                .navTo("dashboard");

        },

        onLogout: function () {

            sessionStorage.clear();

            this.getOwnerComponent()
                .getRouter()
                .navTo("login");

        }

    });

});