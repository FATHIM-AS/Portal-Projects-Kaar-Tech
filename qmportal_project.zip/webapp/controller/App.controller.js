sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    "use strict";

    return Controller.extend("com.kaar.qmportal.controller.App", {

        onInit: function () {

        }

    });

});