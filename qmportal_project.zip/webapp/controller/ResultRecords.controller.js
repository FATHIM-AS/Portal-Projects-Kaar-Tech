sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast"
], function (
    Controller,
    JSONModel,
    Filter,
    FilterOperator,
    MessageToast
) {
    "use strict";

    return Controller.extend(
        "com.kaar.qmportal.controller.ResultRecords",
        {

            onInit: function () {

                this._loadData();

            },

            _loadData: function () {

                var oModel =
                    this.getOwnerComponent().getModel();

                oModel.read("/ResultSet", {

                    success: function (oData) {

                        var oJsonModel =
                            new JSONModel(oData);

                        this.getView().setModel(
                            oJsonModel,
                            "results"
                        );

                        this._updateRecordCount();

                    }.bind(this),

                    error: function (oError) {

                        console.log(oError);

                        MessageToast.show(
                            "Failed to load result data"
                        );

                    }

                });

            },

            onSearch: function () {

                this._applyFilters();

            },

            onFilterChange: function () {

                this._applyFilters();

            },

            _applyFilters: function () {

                var aFilters = [];

                var sSearch =
                    this.byId("resultSearchField")
                        .getValue();

                var sPlant =
                    this.byId("plantFilter")
                        .getSelectedKey();

                var sStatus =
                    this.byId("statusFilter")
                        .getSelectedKey();

                var sInspectionType =
                    this.byId("inspectionTypeFilter")
                        .getSelectedKey();

                if (sSearch) {

                    aFilters.push(

                        new Filter({

                            filters: [

                                new Filter(
                                    "Inspectionlot",
                                    FilterOperator.Contains,
                                    sSearch
                                ),

                                new Filter(
                                    "Characteristicdescription",
                                    FilterOperator.Contains,
                                    sSearch
                                ),

                                new Filter(
                                    "Material",
                                    FilterOperator.Contains,
                                    sSearch
                                )

                            ],

                            and: false

                        })

                    );

                }

                if (sPlant) {

                    aFilters.push(

                        new Filter(
                            "Plant",
                            FilterOperator.EQ,
                            sPlant
                        )

                    );

                }

                if (sStatus) {

                    aFilters.push(

                        new Filter(
                            "Inspectionstatus",
                            FilterOperator.EQ,
                            sStatus
                        )

                    );

                }

                if (sInspectionType) {

                    aFilters.push(

                        new Filter(
                            "Inspectiontype",
                            FilterOperator.Contains,
                            sInspectionType
                        )

                    );

                }

                this.byId("resultTable")
                    .getBinding("rows")
                    .filter(aFilters);

                this._updateRecordCount();

            },

            _updateRecordCount: function () {

                var iCount =
                    this.byId("resultTable")
                        .getBinding("rows")
                        .getLength();

                this.byId("resultCount")
                    .setText(
                        iCount + " Records Found"
                    );

            },

            onRefresh: function () {

                this.byId("resultSearchField")
                    .setValue("");

                this.byId("plantFilter")
                    .setSelectedKey("");

                this.byId("statusFilter")
                    .setSelectedKey("");

                this.byId("inspectionTypeFilter")
                    .setSelectedKey("");

                this._loadData();

            },

            onNavBack: function () {

                this.getOwnerComponent()
                    .getRouter()
                    .navTo("dashboard");

            },

            onLogout: function () {

                sessionStorage.clear();

                this.getOwnerComponent()
                    .getRouter()
                    .navTo("login");

            }

        }
    );

});