sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
], function (
    Controller,
    JSONModel
) {
    "use strict";

    return Controller.extend("project1.controller.Risk", {

        onInit: function () {

            var oODataModel =
                this.getOwnerComponent().getModel();

            oODataModel.read("/RiskSet", {

                success: function (oData) {

                    var oJsonModel =
                        new JSONModel(oData.results);

                    this.getView().setModel(
                        oJsonModel,
                        "riskModel"
                    );

                    this.getView().setModel(
                        oJsonModel,
                        "filteredRiskModel"
                    );

                }.bind(this),

                error: function () {

                    console.log("Risk data load failed");

                }

            });

        },

        onBack: function () {

            this.getOwnerComponent()
                .getRouter()
                .navTo("dashboard");

        },

        onSearch: function () {

            this.applyFilters();

        },

        onFilter: function () {

            this.applyFilters();

        },

        applyFilters: function () {

            var aData =
                this.getView()
                    .getModel("riskModel")
                    .getData();

            var sSearch =
                this.byId("riskSearch")
                    .getValue()
                    .toLowerCase();

            var sStatus =
                this.byId("riskStatusFilter")
                    .getSelectedKey();

            var sSeverity =
                this.byId("severityFilter")
                    .getSelectedKey();

            var aFilteredData =
                aData.filter(function (oItem) {

                    var bSearch = true;
                    var bStatus = true;
                    var bSeverity = true;

                    if (sSearch) {

                        bSearch =
                            oItem.RiskId
                                .toLowerCase()
                                .includes(sSearch);

                    }

                    if (sStatus) {

                        bStatus =
                            oItem.Status === sStatus;

                    }

                    if (sSeverity) {

                        bSeverity =
                            oItem.Severity === sSeverity;

                    }

                    return bSearch &&
                           bStatus &&
                           bSeverity;

                });

            var oFilteredModel =
                new JSONModel(aFilteredData);

            this.getView().setModel(
                oFilteredModel,
                "filteredRiskModel"
            );

        }

    });

});