sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (
    Controller
) {
    "use strict";

    return Controller.extend("project1.controller.Dashboard", {

        onIncidentPress: function () {

            this.getOwnerComponent()
                .getRouter()
                .navTo("incident");

        },

        onRiskPress: function () {

            this.getOwnerComponent()
                .getRouter()
                .navTo("risk");

        },

        onLogout: function () {

            this.getOwnerComponent()
                .getRouter()
                .navTo("login");

        }

    });

});