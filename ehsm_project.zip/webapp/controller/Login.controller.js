sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast"
], function (Controller, MessageToast) {
    "use strict";

    return Controller.extend("project1.controller.Login", {

        onLogin: function () {

            var oModel = this.getView().getModel();

            var sEmpId = this.byId("empId").getValue();
            var sPassword = this.byId("password").getValue();

            var oPayload = {
                EmpId: sEmpId,
                Password: sPassword
            };

            oModel.create("/LoginSet", oPayload, {

                success: function (oData) {

                    if (oData.Status === true) {

                        MessageToast.show("Login Successful");

                        sap.ui.core.UIComponent
                            .getRouterFor(this)
                            .navTo("dashboard");

                    } else {
                        MessageToast.show("Invalid Credentials");
                    }

                }.bind(this),

                error: function () {
                    MessageToast.show("Login Failed");
                }

            });

        }

    });

});