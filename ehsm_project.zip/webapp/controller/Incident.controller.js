sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
], function (
    Controller,
    JSONModel
) {
    "use strict";

    return Controller.extend("project1.controller.Incident", {

        onInit: function () {

            var oODataModel =
                this.getOwnerComponent().getModel();

            oODataModel.read("/IncidentSet", {

                success: function (oData) {

                    var oJsonModel =
                        new JSONModel(oData.results);

                    this.getView().setModel(
                        oJsonModel,
                        "incidentModel"
                    );

                    this.getView().setModel(
                        oJsonModel,
                        "filteredIncidentModel"
                    );

                }.bind(this),

                error: function () {

                    console.log("Incident data load failed");

                }

            });

        },

        onBack: function () {

            this.getOwnerComponent()
                .getRouter()
                .navTo("dashboard");

        },

        onSearch: function () {

            this.applyFilters();

        },

        onFilter: function () {

            this.applyFilters();

        },

        applyFilters: function () {

            var aData =
                this.getView()
                    .getModel("incidentModel")
                    .getData();

            var sSearch =
                this.byId("incidentSearch")
                    .getValue()
                    .toLowerCase();

            var sStatus =
                this.byId("incidentStatusFilter")
                    .getSelectedKey();

            var sPlant =
                this.byId("plantFilter")
                    .getSelectedKey();

            var aFilteredData =
                aData.filter(function (oItem) {

                    var bSearch = true;
                    var bStatus = true;
                    var bPlant = true;

                    if (sSearch) {

                        bSearch =
                            oItem.IncidentId
                                .toLowerCase()
                                .includes(sSearch);

                    }

                    if (sStatus) {

                        bStatus =
                            oItem.Status === sStatus;

                    }

                    if (sPlant) {

                        bPlant =
                            oItem.Werks === sPlant;

                    }

                    return bSearch &&
                           bStatus &&
                           bPlant;

                });

            var oFilteredModel =
                new JSONModel(aFilteredData);

            this.getView().setModel(
                oFilteredModel,
                "filteredIncidentModel"
            );

        }

    });

});